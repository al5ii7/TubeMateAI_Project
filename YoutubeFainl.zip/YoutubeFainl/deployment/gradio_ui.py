import gradio as gr
from translate import translate_text
from bot import load_video
from audio_utils import handle_chat, ui_load_video

def build_interface():
 with gr.Blocks(css="""
     .gradio-container {
        background-color: rgba(240, 93, 14, 0.15)   !important;
        color: black !important;
        font-family: 'Segoe UI', sans-serif;
    }

    .centered {
        text-align: center;
    }

    textarea, input, .gr-textbox, .gr-input {
        background-color: white !important;
        color: black !important;
        border-radius: 8px;
        padding: 10px;
        font-size: 16px;
    }

    button, .gr-button {
        background-color: white !important;
        color: black !important;
        border: 1px solid rgba(0, 0, 0, 0.2) !important; 
        border-radius: 8px !important;
        font-weight: bold !important;
        padding: 8px 16px !important;
        transition: background-color 0.3s ease, color 0.3s ease;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);  
    }

    button:hover, .gr-button:hover {
        background-color: #F3732F !important;
        color: white !important;
    }

    .gr-markdown h3 {
        color: black !important;
        margin-top: 20px;
    }
                
    input[type="checkbox"] {
    cursor: pointer;
    transform: scale(1.2);
    margin-right: 8px;
}
                
    .gr-chatbot {
        background-color: rgba(255, 255, 255, 0.1) !important;
        border-radius: 12px;
        padding: 10px;
    }
                
     """) as demo:
        
        gr.HTML("<h1 class='centered'> TubeMate AI</h1>")

        original_transcript = gr.State("")
        original_summary = gr.State("")
        conversation = gr.State([])

        # URL Input + Load Button
        with gr.Column():
            url_input = gr.Textbox(label="YouTube URL", placeholder="Enter YouTube link here...")
            load_button = gr.Button("Submit")

        # Summary and Transcript Side by Side
        with gr.Row():
            with gr.Column():
                with gr.Accordion("Summary", open=False):
                    summary_box = gr.Textbox(lines=10, interactive=False, show_label=False)
                    with gr.Row():
                        translate_summary_btn = gr.Button(" Translate Summary to Arabic")
                        restore_summary_btn = gr.Button(" Restore Original Summary")

            with gr.Column():
                with gr.Accordion("Transcript", open=False):
                    transcript_box = gr.Textbox(lines=10, interactive=False, show_label=False)
                    with gr.Row():
                        translate_transcript_btn = gr.Button("Translate Transcript to Arabic")
                        restore_transcript_btn = gr.Button("Restore Original Transcript")

        # Chatbot Section
        gr.Markdown("# ChatBot")

        chatbot = gr.Chatbot(label="Video QA Chat", show_label=False)

        with gr.Row():
            text_input = gr.Textbox(label="Ask your question", placeholder="Ask about the video...", scale=4)
            audio_input = gr.Audio(source="microphone", type="filepath", label="🎤", interactive=True)

        with gr.Column():
            voice_toggle = gr.Checkbox(label="Voice reply?", value=False, interactive=True)
            send_btn = gr.Button("Send")

        audio_output = gr.Audio(label="Bot Voice Reply", type="filepath")

        # Functional Hooks
        load_button.click(fn=ui_load_video, inputs=[url_input],
                          outputs=[transcript_box, summary_box, original_transcript, original_summary])

        translate_summary_btn.click(fn=lambda x: translate_text(x, "ar"), inputs=summary_box, outputs=summary_box)
        restore_summary_btn.click(fn=lambda x: x, inputs=original_summary, outputs=summary_box)

        translate_transcript_btn.click(fn=lambda x: translate_text(x, "ar"), inputs=transcript_box, outputs=transcript_box)
        restore_transcript_btn.click(fn=lambda x: x, inputs=original_transcript, outputs=transcript_box)

        send_btn.click(
            fn=handle_chat,
            inputs=[audio_input, text_input, conversation, voice_toggle],
            outputs=[chatbot, conversation, text_input, audio_input, audio_output]
        )

        return demo
