import os
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def summarize_transcript(transcript: str, duration: float) -> str:
    """Classify and summarize a YouTube video transcript using GPT-4."""
    prompt = f"""
You are a helpful assistant. First, classify the following YouTube video transcript into one of these categories:

["Entertainment", "Religious", "Educational", "Podcast", "Sports", "Economic", "Political", "News", "Music", "Cultural", "Self-Development", "Technology"]

Respond with the category in the first line.

Then, provide:
1. An introduction.
2. The main topic.
3. A content overview.
4. Key points discussed.
5. A conclusion.

Transcript:
{transcript}
"""

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.5,
        max_tokens=1000
    )

    return response.choices[0].message.content.strip()

