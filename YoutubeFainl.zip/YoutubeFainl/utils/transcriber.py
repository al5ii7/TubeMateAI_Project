import whisper
from yt_dlp import YoutubeDL
import os

def select_whisper_model(duration_seconds: float) -> str:
    if duration_seconds < 5 * 60:
        return "tiny"
    elif duration_seconds < 20 * 60:
        return "base"
    elif duration_seconds < 60 * 60:
        return "small"
    elif duration_seconds < 2 * 60 * 60:
        return "medium"
    else:
        return "large"

def download_audio(youtube_url: str, out_dir: str = "downloads") -> tuple[str, float]:
    os.makedirs(out_dir, exist_ok=True)
    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': f'{out_dir}/%(id)s.%(ext)s',
        'quiet': True,
    }
    with YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(youtube_url, download=True)
    audio_path = f"{out_dir}/{info['id']}.{info['ext']}"
    duration = info.get('duration', 0)
    return audio_path, duration

def transcribe_audio(audio_path: str, duration: float) -> tuple[str, list[dict]]:
    model_name = select_whisper_model(duration)
    model = whisper.load_model(model_name)

    # Let Whisper handle language detection and transcription
    result = model.transcribe(audio_path)
    
    # Optional: print detected language
    language = result.get("language", "unknown")
    print(f"Detected language: {language}")

    # Full transcript
    transcript = result.get("text", "")

    # Segments with timestamp formatting
    segments = result.get("segments", [])
    for seg in segments:
        start, end = seg["start"], seg["end"]
        seg["start_ts"] = f"{int(start//60):02d}:{int(start%60):02d}"
        seg["end_ts"]   = f"{int(end//60):02d}:{int(end%60):02d}"

    return transcript, segments
