import tempfile
from openai import OpenAI
from gtts import gTTS
from dotenv import load_dotenv
import os
from bot import load_video, run_agent_tool
from utils.transcriber import transcribe_audio 

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def ui_load_video(youtube_url: str):
    transcript, summary = load_video(youtube_url)
    return transcript, summary, transcript, summary

def ui_transcribe_audio(audio_path):
    """Transcribe audio file via Whisper."""
    if not audio_path:
        return "❗️ Please upload an audio file first."
    with open(audio_path, "rb") as f:
        resp = client.audio.transcriptions.create(
            model="whisper-1",
            file=f,
            response_format="text",
            language="en"
        )
    return resp

def handle_chat(audio_path, user_text, history, voice_on):
    """
    Handles chat interaction, transcription, and optional voice reply.
    """
    history = history or []

    # 1. Get the user's question (text or transcribed audio)
    if user_text and user_text.strip():
        question = user_text.strip()
    elif audio_path:
        question = ui_transcribe_audio(audio_path).strip()
        if question.startswith("❗️"):
            history.append(("user", question))
            return history, history, "", None, None
    else:
        return history, history, "", None, None

    # 2. Append user question to conversation
    history.append(("user", question))

    # 3. Get assistant's answer from the agent
    answer = run_agent_tool(f"query_video {question}").strip()
    history.append(("assistant", answer))

    # 4. If voice reply is enabled, generate TTS
    audio_response_path = None
    if voice_on:
        tts = gTTS(text=answer, lang='en')  # optional: detect language
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as fp:
            tts.save(fp.name)
            audio_response_path = fp.name

    # 5. Return conversation and audio
    return history, history, "", None, audio_response_path
