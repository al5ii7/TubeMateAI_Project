import os
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def translate_text(text: str, target_lang: str = "ar") -> str:
    """Translate text to the specified language using GPT."""
    if not text:
        return ""
    
    prompt = f"Translate the following text to {target_lang}:\n\n{text}"
    
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
        max_tokens=1000
    )

    return response.choices[0].message.content.strip()
