import os
import gradio as gr
from openai import OpenAI
from gtts import gTTS
from bot import load_video, run_agent_tool, video_state
from dotenv import load_dotenv
from translate import translate_text
from gradio_ui import build_interface

os.environ["LANGCHAIN_API_KEY"] = "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"
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_PROJECT"] = "VideoQA-Agent"



if __name__ == "__main__":
    demo = build_interface()
    demo.launch(share=False)
