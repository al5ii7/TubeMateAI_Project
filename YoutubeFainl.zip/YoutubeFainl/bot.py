from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA
from langchain.text_splitter import TokenTextSplitter
from langchain.docstore.document import Document
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import Chroma
from langchain.agents import Tool, initialize_agent, AgentType
import re, os, openai
from utils.transcriber import download_audio, transcribe_audio
from utils.summarizer import summarize_transcript

openai.api_key = os.getenv("OPENAI_API_KEY")

video_state = {"transcript": None, "segments": [], "duration": 0.0}
qa_chain_stuff = None
qa_chain_map_reduce = None
agent = None

# RAG Pipeline: Question Answering Function
def videoqa_with_time(question: str) -> str:
    """
    1) Handle timestamp queries like “What was said at minute X?” directly from segments.
    2) Route other questions to the appropriate RAG chain.
    3) Post‐process model output to collapse any “no info” responses into a unified fallback.
    """
    # 1) Handle timestamp queries first
    time_match = re.search(r"(\d+(?:\.\d+)?)\s*minute", question, re.IGNORECASE)
    if time_match and video_state["segments"]:
        sec = float(time_match.group(1)) * 60
        for seg in video_state["segments"]:
            if seg["start"] <= sec <= seg["end"]:
                st = seg.get("start_ts", f"{seg['start']:.1f}s")
                et = seg.get("end_ts",   f"{seg['end']:.1f}s")
                return f"{seg['text']} (from {st} to {et})"
        # If the requested timestamp is outside the known segments:
        return "Sorry, that question is outside the video content."

    # 2) Regular questions: choose short (stuff) vs. long (map_reduce) chain
    if len(question) < 120:
        raw = qa_chain_stuff.run(question)
    else:
        raw = qa_chain_map_reduce.run(question)

    # 3) If the model indicates missing information, override with our fallback
    low = raw.strip().lower()
    if any(phrase in low for phrase in [
    "the transcript does not",
    "the provided transcript does not",
    "sorry",
    "outside the video content"
]):

        return "Sorry, that question is outside the video content."

    # 4) Otherwise, return the model’s answer
    return raw

# RAG Pipeline Entry Point
def load_video(url: str):
    global qa_chain_stuff, qa_chain_map_reduce, agent, video_state
# Phase 1: Data Preparation
    audio_path, duration = download_audio(url)
    transcript, segments = transcribe_audio(audio_path, duration)
    video_state.update({"transcript": transcript, "segments": segments, "duration": duration})

    splitter = TokenTextSplitter(chunk_size=1000, chunk_overlap=200)
    docs = [Document(page_content=chunk) for chunk in splitter.split_text(transcript)]
    vectordb = Chroma.from_documents(docs, OpenAIEmbeddings())
 
 # Phase 2: Retrieval-Augmented Generation
    video_prompt = PromptTemplate(
        input_variables=["context", "question"],
        template=(
            "You are a video assistant that only answers using the provided transcript context.\n\n"
             "Context:\n{context}\n\n"
             "Question: {question}\n"
             "Answer:"
        )
    )

    llm = ChatOpenAI(model_name="gpt-4", temperature=0)

    qa_chain_stuff = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=vectordb.as_retriever(search_kwargs={"k": 5}),
        chain_type_kwargs={"prompt": video_prompt},
        return_source_documents=False
    )

    # Corrected combine_prompt uses 'summaries'
    combine_prompt = PromptTemplate(
        input_variables=["summaries", "question"],
        template=(
            "Combine the following extracted snippets into one detailed answer:\n"
            "{summaries}\n\n"
            "Original question: {question}\n"
            "Final answer:"
        )
    )

    qa_chain_map_reduce = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="map_reduce",
        retriever=vectordb.as_retriever(search_kwargs={"k": 3}),
        chain_type_kwargs={
            "question_prompt": video_prompt,
            "combine_prompt": combine_prompt
        },
        return_source_documents=False
    )

    video_qa_tool = Tool(
        name="VideoQA",
        func=videoqa_with_time,
        description="Answer questions from the video, including timestamp queries."
    )
    agent = initialize_agent(
        tools=[video_qa_tool],
        llm=llm,
        agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        verbose=False,
        agent_kwargs={"prefix": "You are a video assistant. Always use the VideoQA tool. If you can't answer from the video, say: 'Sorry, that is outside the video content.'"}
    )

    return transcript, summarize_transcript(transcript, duration)

def run_agent_tool(command: str) -> str:
    cmd, _, arg = command.partition(" ")
    if cmd == "load_video":
        return load_video(arg)
    if cmd == "query_video":
        return agent.run(arg)  
    return "Unknown command. Use 'load_video <url>' or 'query_video <question>'."